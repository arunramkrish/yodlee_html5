// document.getElementById("ajaxButton").onclick = function() {
// makeRequest('test.html'); };
// document.onload = function() {
var httpRequest;
makeRequest('teams.json', alertContents);
makeRequest('caps', alertContents);

// };

function makeRequest(url, handler) {
	if (window.XMLHttpRequest) { // Mozilla, Safari, ...
		httpRequest = new XMLHttpRequest();
	} else if (window.ActiveXObject) { // IE
		try {
			httpRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {
			}
		}
	}

	if (!httpRequest) {
		alert('Giving up :( Cannot create an XMLHTTP instance');
		return false;
	}
	httpRequest.onreadystatechange = handler;
	httpRequest.open('GET', url);
	httpRequest.send();
}

function alertContents() {
	if (httpRequest.readyState === 4) {
		if (httpRequest.status === 200) {
			var caps = httpRequest.responseText; 
			alert(caps.orangeCap);
		} else {
			alert('There was a problem with the request.');
		}
	}
}
