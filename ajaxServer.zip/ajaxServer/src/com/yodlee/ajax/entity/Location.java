package com.yodlee.ajax.entity;

public class Location {
	private String location;
	private String tag;
	
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Location(String location, String tag) {
		super();
		this.location = location;
		this.tag = tag;
	}
	@Override
	public String toString() {
		return "Location [location=" + location + ", tag=" + tag + "]";
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	
	
}
