package com.yodlee.ajax.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yodlee.ajax.dao.LocationDao;
import com.yodlee.ajax.entity.Location;

/**
 * Servlet implementation class LocationsServlet
 */
@WebServlet("/locations")
public class LocationsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LocationDao locDao = new LocationDao();
	
    /**
     * Default constructor. 
     */
    public LocationsServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Location> locations = locDao.get();
		
		StringBuffer locString = new StringBuffer("[");
		boolean isFirst = true;
		
		for (Location loc : locations) {
			if (!isFirst) {
				locString.append(",");
			}
			isFirst = false;
			locString.append("{");
			
			locString.append("location:" + "\"" + loc.getLocation() + "\",");
			locString.append("tag:" + "\"" + loc.getTag() + "\"");
			
			locString.append("}");
		}
		
		locString.append("]");
		
		response.getOutputStream().println(locString.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Location loc = new Location();
		loc.setLocation(request.getParameter("location"));
		loc.setTag(request.getParameter("tag"));
		
		locDao.create(loc);
		
		//response.getOutputStream().println("success");
		
		doGet(request, response);
	}

}
