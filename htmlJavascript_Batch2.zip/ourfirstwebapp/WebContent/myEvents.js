function calculate(myform) {
	var ip1 = myform["input1"].value;
	var fact = 1;
	for (var i=1;i<=ip1;i++) {
		fact *= i;
	}
	myform["input2"].value = fact;
}
function calculateGcd(myButton) {
	var myForm = document.getElementById("inputForm");
	alert(myForm["input2"].value);
}
var loadFunction = function() {
	counter.increment();
	console.log(counter.displayText + counter.getCount());
};
loadFunction();
var myfun = calculateGcd;
myfun(null);
function bodyLoaded(loadMe) {
	loadMe();
}