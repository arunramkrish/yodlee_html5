function Counter() {
	var count = 0;
	this.name ="Counter";
	this.increment = function() {
		count++;
	};
	this.decrement = function() {
		count--;
	};
	this.getCount = function() {
		return count;
	};
}

var counter = new Counter();
Counter.prototype.displayText = "My Javasccript counter";

var counter2 = new Counter();
console.log(counter2.displaytext);