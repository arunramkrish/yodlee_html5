var iplTeam = {
	name: "CSK",
	owner: "India Cements",
	getPlayers: function() {
		var players = ["MSD","Raina","McCullum"]; 
		return players;
	}
};

var iplFromObject = new Object();
iplFromObject.name ="RCB";
iplFromObject.owner="UB";

console.log(JSON.stringify(iplFromObject));

var objFromJson = JSON.parse({'name':'KKR','owner':'SRK'});
console.log(objFromJson.name);
console.log(iplTeam.name);

var numArray = [1,2,4,18];
for(var i=0;i<numArray.length;i++) {
	console.log(numArray[i]);
}

Array.prototype.myForEach = function(array, myItemFunction) {
	for (var i=0;i<array.length;i++) {
		myItemFunction(i, array, array[i]);
	}
};
numArray.myForEach(numArray, function(index, arr, element) {
	console.log(element);
});

var myArrayObject = new Array();
myArrayObject.push("arrayObj1");
myArrayObject.push("arrayObj2");

var iplTeams = [{'name':'KKR','owner':'SRK'}, {'name':'KKR','owner':'SRK'}]