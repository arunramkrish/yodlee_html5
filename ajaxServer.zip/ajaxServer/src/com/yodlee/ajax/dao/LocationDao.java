package com.yodlee.ajax.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yodlee.ajax.entity.Location;

public class LocationDao {
	public Location create(Location location) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = DatabaseUtil.getConnection();
			
			stmt = conn.prepareStatement("insert into locations (location, tag) "
					+ " values (?, ?)");
			
			//set params
			stmt.setString(1, location.getLocation());
			stmt.setString(2, location.getTag());
			
			//execute
			stmt.executeUpdate();
			
			return location;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.releaseResources(conn, stmt, null);
		}
		return location;
	}
	
	public List<Location> get() {
		List<Location> locations = new ArrayList<Location>();
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = DatabaseUtil.getConnection();
			
			stmt = conn.prepareStatement("select location, tag from locations");
			
			rs = stmt.executeQuery();
			
			while (rs.next()) {
				Location l = new Location();
				l.setLocation(rs.getString(1));
				l.setTag(rs.getString(2));
		
				locations.add(l);
			}
			
			return locations;
		} catch (SQLException e) {
			e.printStackTrace();
			return locations;
		} finally {
			DatabaseUtil.releaseResources(conn, stmt, null);
		}
	}

}
